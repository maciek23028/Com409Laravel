@extends('layouts.mainPageLayout')

@section('content')
<div>
	<link href="{{ asset('css/singleMovie.css') }}" rel="stylesheet">
	<br />
	<br />
	<br />
	<div class="rectangle">
	<!-- display movie title-->
	<h1 class = "title">{{$movie->title}}</h1>
	<p1 class="genre">{{$movie->genre}}</p1>
	<!-- display movie image-->

	<br />
	<br />
	<br />
	<!-- display movie description-->
	<h2>Description: <br /></h2>
	<p2 class="decription">{{$movie->description}}</p2>
	<!-- display movie rating-->
	<!-- display movie trailers-->
	<!-- display movie cast-->
	<h2 class="cast">Cast</h2>
	<p3 class="cast">{{$movie->cast}}<br /></p3>
	<!-- display movie author/director-->
	<h2 class="author">Author</h2>
	<p4 class="author">{{$movie->author}}<br /></p4>
	<!-- Comments section-->
	<br />
	<h2 class="comments">Comments</h2>
	</div>
</div>
@stop

<?php echo $__env->yieldContent('additionalMenu'); ?>
<div class="extraFeatures">
<br />
<br />

<br />
<br />
<br />


			<!-- search bar-->
                        <div class="searchbar">
                           <div class="search">
                              <input type="text" class="searchTerm" placeholder="Search">
                              <button type="submit" class="searchButton">
                                <i class="fa fa-search" aria-hidden="true"></i>
                             </button>
                           </div>
                        </div>
            
</div>
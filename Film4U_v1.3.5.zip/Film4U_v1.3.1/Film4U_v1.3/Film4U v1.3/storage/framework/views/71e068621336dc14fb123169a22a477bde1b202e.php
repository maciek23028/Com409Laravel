        <?php echo $__env->yieldContent('footer'); ?>
        <!--- break here for footer ---->

        <footer id="footer">
        	<!--<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">-->
        	<h1>FILM4U</h1><p1>Content Of the footer paragraph</p1></footer>


    </div>
</body>
</html>


@extends('layouts.mainPageLayout')
@section('content')
<!--enter content-->
<link href="{{ asset('css/displayAll.css') }}" rel="stylesheet">
<div class="rectangle">
	<h1>All</h1>
</div>

@stop
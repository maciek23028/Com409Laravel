<?php

use Faker\Generator as Faker;

$factory->define(App\Cast::class, function (Faker $faker) {
	
            return [
        'actor_id' => App\Actor::pluck('id')->random(),
    	'characterPlayed' => $faker->name(),
        'movie_id' => App\Movie::pluck('id')->random(),

        
    ];
});

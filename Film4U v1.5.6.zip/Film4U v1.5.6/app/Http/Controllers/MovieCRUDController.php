<?php

namespace App\Http\Controllers;
use View;
use Illuminate\Http\Request;
use App\Movie;
use App\Http\Controllers\Controller;


class MovieCRUDController extends Controller
{
        public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function guard(){
        return Auth::guard('admin');
    }



	public function CMS(Request $request)
    {   $movies = Movie::orderBy('id','DESC')->paginate(10);
        return view('CMS' , compact('movies'))->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function CMSCreate(){
        return view('CRUDfolder.Create');
    }

    public function store(array $data)
    {
        return Validator::make($data, [
            'title' => ['required', 'string', 'max:100'],
             'genre' => ['required', 'string', 'max:20'],
            'length' => ['required', 'numeric','max:400'],
            'description' => ['required','string','max:500'],
            'author' => ['required','string','max:100'],
            'releaseDate' => ['required','string','max:50'],
            'mediaType_id' => ['required','string','max:2'],
        ]);
    }

    public function addMovieToDB(array $data){

        return Movies::create([
            'title' => $data['title'],
             'genre' => $data['genre'],
            'length' => $data['length'],
            'description' => $data['description'],
            'author' => $data['author'],
            'releaseDate' => $data['releaseDate'],
            'mediaType_id' => $data['mediaType_id'],
        ]);
    }

    public function CMSSee(Movie $movie)
    {
        return view ('CRUDfolder.See')->withMovie($movie);
    }
 
    public function CMSEdit(Movie $movie)
    {
        return view('CRUDfolder.Edit')->withMovie($movie);
    }
 
    public function CMSUpdate(Request $request, Movie $id)
    {

         $this-> Validator::make($data, [
            'title' => ['required', 'string', 'max:100'],
             'genre' => ['required', 'string', 'max:20'],
            'length' => ['required', 'numeric','max:400'],
            'description' => ['required','string','max:500'],
            'author' => ['required','string','max:100'],
            'releaseDate' => ['required','string','max:50'],
            'mediaType_id' => ['required','string','max:2'],
        ]);

        $requestData = $request->all();
        Movie::find($id)->update($requestData);
        return redirect()->route('CRUDfolder.CMS')
                        ->with('success','Record updated successfully');
    }
    public function CMSDelete($id)
    {
        Movie::find($id)->delete();
        return redirect()->route('CRUDfolder.CMS')
                        ->with('success','Record deleted successfully');
    }
}



<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use AuthenticatesUsers;
use DB;
use View;
use App\Admin;


class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {   //use admin guard
        $this->middleware('auth:admin');
    }

    public function guard(){
        return Auth::guard('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   //admin dashboard
        return view('admin');
    }

    
}

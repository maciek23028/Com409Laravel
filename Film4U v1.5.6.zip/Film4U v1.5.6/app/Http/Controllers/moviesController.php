<?php

namespace App\Http\Controllers;
use View;
use App\Movie;
use App\PhotoLocation;
use App\Actor;
use App\Cast;
use Illuminate\Http\Request;

class moviesController extends Controller
{
    
	public function index(){
        //Movie
    	//$movies = Movie::get();
    	$movies=Movie::all();
        $photos = PhotoLocation::all();
    	return View::make ('movies.index')->withMovies($movies)->withPhotos($photos);
    }

    public function show(Movie $movie)
    {   //movie/movieID
    	return view ('movies.contentOfMovie')->withMovie($movie);
    }

    public function showMain()
    {   //main
    	return view ('layouts.main');
    }

    public function findMovie(){
    	$movieId = Movie::Find(1);
    	return view ('movies.index')->withMovie($movieId);
    }
    public function mainPage(){
        //mainPageLayout
        return view ('layouts.mainPageLayout');
    }


        //get photo path
       /* public function getPhotoPath(PhotoLocation $path){
        return $photoPath = $path;
    }*/

}



@extends('layouts.admin-mainPageLayout')

@section('content')

<div class="container">
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Edit Movie') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('CMS') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="title" class="col-md-4 col-form-label text-md-right">{{ __('Movie title') }}</label>

                            <div class="col-md-6">
                                <input id="title" type="text" class="form-control{{ $errors->has('title') ? ' is-invalid' : '' }}" name="title" value="{{ old('title') }}" placeholder="{{ $movie->title}} " required autofocus>

                                @if ($errors->has('title'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('title') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="genre" class="col-md-4 col-form-label text-md-right">{{ __('Genre') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control{{ $errors->has('genre') ? ' is-invalid' : '' }}" name="genre" value="{{ old('genre') }}" placeholder="{{ $movie->genre}}" required autofocus>

                                @if ($errors->has('genre'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('genre') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        

                        <div class="form-group row">
                            <label for="length" class="col-md-4 col-form-label text-md-right">{{ __('Movie Length') }}</label>

                            <div class="col-md-6">
                                <input id="length" type="number" class="form-control{{ $errors->has('length') ? ' is-invalid' : '' }}" name="length" value="{{ old('length') }}" placeholder="{{ $movie->length}}"required>

                                @if ($errors->has('length'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('length') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right">{{ __('Description') }}</label>

                            <div class="col-md-6">
                                <input id="description" type="text" class="form-control{{ $errors->has('description') ? ' is-invalid' : '' }}" name="description" placeholder="{{ $movie->description}}" required>

                                @if ($errors->has('description'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="author" class="col-md-4 col-form-label text-md-right">{{ __('Author') }}</label>

                            <div class="col-md-6">
                                <input id="author" type="text" class="form-control{{ $errors->has('author') ? ' is-invalid' : '' }}" name="author" placeholder="{{ $movie->author}}" required>

                                @if ($errors->has('author'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('author') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="releaseDate" class="col-md-4 col-form-label text-md-right">{{ __('Release Date') }}</label>

                            <div class="col-md-6">
                                <input id="releaseDate" type="date" class="form-control{{ $errors->has('releaseDate') ? ' is-invalid' : '' }}" name="releaseDate" placeholder="{{ $movie->releaseDate}}" required>

                                @if ($errors->has('releaseDate'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('releaseDate') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="mediaType_id" class="col-md-4 col-form-label text-md-right">{{ __('1 Movie, 2 Series') }}</label>

                            <div class="col-md-6">
                                <input id="mediaType_id" type="number" class="form-control{{ $errors->has('mediaType_id') ? ' is-invalid' : '' }}" name="mediaType_id" placeholder="{{ $movie->mediaType_id}}"required>

                                @if ($errors->has('movieType_id'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('mediaType_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Update Movie') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
   
   
@endsection

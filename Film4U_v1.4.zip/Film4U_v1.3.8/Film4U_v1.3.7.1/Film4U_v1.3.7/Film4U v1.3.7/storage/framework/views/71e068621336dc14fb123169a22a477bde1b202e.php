        <?php echo $__env->yieldContent('footer'); ?>
        <!--- break here for footer ---->

        <footer id="footer">
        	<h1>FILM4U</h1><p>Copyright Ⓒ Lorem Ipsum</p></footer>
    </div>
</body>
</html>


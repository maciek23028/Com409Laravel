<?php

use Illuminate\Database\Seeder;

class movieLinksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\MovieLink::class, 8)->create();
    }
}

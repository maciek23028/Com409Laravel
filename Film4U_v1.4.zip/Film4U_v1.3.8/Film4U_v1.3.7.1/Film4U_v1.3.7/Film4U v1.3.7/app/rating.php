<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rating extends Model
{
        /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'movie_id','users_id','rating',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'users_id','id','movie_id',
    ];
}

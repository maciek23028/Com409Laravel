@extends('layouts.mainPageLayout')

@section('content')
<link href="{{ asset('css/main.css') }}" rel="stylesheet">
<section id="currentLocation">
		<h1>Movies</h1>
</section>
<div class="rectangle">
			<section id="Images">

				@foreach ($movies as $movie)
				
				
					<a href="{{route('showMovie',$movie->id)}}">
						<div class="image">
					 <img src="https://ulster-my.sharepoint.com/:i:/r/personal/rozmiarek-m_ulster_ac_uk/Documents/MovieImagePlaceholder.jpg?csf=1&e=BU2ZcU" alt="{{$movie->title}}">
					 </div>
					</a>
				

				@endforeach

			</section>
			
			<br />
			<br />
			<br />

	</div>
@stop

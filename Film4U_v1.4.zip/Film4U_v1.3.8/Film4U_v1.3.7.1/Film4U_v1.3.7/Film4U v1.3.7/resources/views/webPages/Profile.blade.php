@extends('layouts.mainPageLayout')
@section('content')
<!--enter content-->
<link href="{{ asset('css/main.css') }}" rel="stylesheet">
<section id="currentLocation">
		<h1>{{ Auth::user()->username}} Profile</h1>
</section>
<div class="rectangle">
	<h1>some Text</h1>
</div>

@stop
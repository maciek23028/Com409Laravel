
@include ('layouts.header')
@section ('header')
@endsection

@include ('layouts.additionalMenu')
@section('additionalMenu')
@endsection

<br />
<br />
<br />
<br />
<div class='pageContent'>
        <main class="py-4">
             @yield('content')
             <!----page content ----->
             <!----end of page content ----->
        </main>
</div>

@include ('layouts.footer')
@section ('footer')
@endsection

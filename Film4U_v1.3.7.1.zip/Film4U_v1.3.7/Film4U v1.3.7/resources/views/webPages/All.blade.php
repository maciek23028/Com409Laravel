@extends('layouts.mainPageLayout')
@section('content')
<!--enter content-->
<link href="{{ asset('css/displayAll.css') }}" rel="stylesheet">
<div class="rectangle">
	<h1>All</h1>
	<div>
		<ul>
			@foreach ($movies as $movie)
			<p><a href="{{route('showMovie',$movie->id)}}">{{$movie->title}}</a></p>
			<p>Description: {{$movie->description}}</p>
			@endforeach
			
		</ul>
		<br />
		<br />
		<br />
	</div>
</div>

@stop
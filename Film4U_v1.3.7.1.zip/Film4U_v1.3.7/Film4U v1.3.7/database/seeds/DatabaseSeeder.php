<?php

use Illuminate\Database\Seeder;


class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         $this->call(UsersTableSeeder::class);
         $this->call(ActorTableSeeder::class);
         $this->call(Category_MovieSeeder::class);
         $this->call(MovieTableSeeder::class);
         $this->call(AdminTableSeeder::class);     
         $this->call(PhotoLocationSeeeder::class);
         $this->call(CastSeeder::class);
         $this->call(comments_movieSeeder::class);
         $this->call(ratingTableSeeder::class);
         $this->call(moodTableSeeder::class);
         $this->call(movieLinksTableSeeder::class);
    }
}

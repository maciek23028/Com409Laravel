

@extends ('layouts.admin-mainPageLayout')

@section('content')
<font color="white">
<link href="{{ asset('css/admin.css') }}" rel="stylesheet">

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">id:</th>
            <th scope="col">Movie Title:</th>
            <th scope="col">Genre:</th>
            <th scope="col">Min:</th>
            <th scope="col">Description</th>
            <th scope="col">Author</th>
            <th scope="col">Release Date</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
    @foreach ($movies as $movie)
    <tr>
        
        <td scope="row">{{ $movie->id }}</td>
        <td scope="row">{{ $movie->title }}</td>
        <td scope="row">{{ $movie->genre }}</td>
        <td scope="row">{{ $movie->length }}</td>
        <td scope="row">{{ $movie->description }}</td>
        <td scope="row">{{ $movie->author}}</td>
        <td scope="row">{{ $movie->releaseDate }}</td>
        <td scope="row">
            <a class="btn btn-primary" id="Viewbtn" href="{{route('CMSSee',$movie->id)}}">View</a>
            <a class="btn btn-primary" id="Editbtn" href="{{ route('CMSEdit',$movie->id) }}">Edit</a>
        </td>
    </tr>
    @endforeach
    </tbody>
    </table> 
    <section id="pages">{!! $movies->render() !!}</section>
@endsection

<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    { //create 44 regular users
  		factory(App\User::class, 10)->create();

  		    DB::table('users')->insert([
            'full_name' => 'Regular User',
            'username' => 'User',
            'email' => 'user@example.com',
            'email_verified_at' => now(),
            'password' => bcrypt('Pas$word'),
            'email_verified_at' => now(),
            'profile' => 'This is my user profile',
            'remember_token' => str_random(10),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
 

}

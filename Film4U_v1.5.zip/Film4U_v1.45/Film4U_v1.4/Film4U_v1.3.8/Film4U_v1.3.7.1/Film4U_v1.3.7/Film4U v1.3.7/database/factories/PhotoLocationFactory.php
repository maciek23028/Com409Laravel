<?php

use Faker\Generator as Faker;
$factory->define(App\PhotoLocation::class, function (Faker $faker) {
    return [
        'photoPath' => $faker->randomElement([
        	'https://ulster-my.sharepoint.com/:i:/r/personal/rozmiarek-m_ulster_ac_uk/Documents/MoviePlaceHolder.jpg?csf=1&e=xDsneS',
        	'https://ulster-my.sharepoint.com/:i:/r/personal/rozmiarek-m_ulster_ac_uk/Documents/seriesPlaceHolder.jpg?csf=1&e=edIO9R',
        ]),
        'movie_id' => App\Movie::pluck('id')->random(),
    ];
});

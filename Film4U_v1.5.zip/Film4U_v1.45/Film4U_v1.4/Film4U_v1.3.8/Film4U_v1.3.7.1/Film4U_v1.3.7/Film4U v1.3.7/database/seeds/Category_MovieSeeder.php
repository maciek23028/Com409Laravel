<?php

use Illuminate\Database\Seeder;

class Category_MovieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\Category_Movie::class, 2)->create();
    }
}

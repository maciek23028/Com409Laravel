<?php $__env->startSection('content'); ?>
<font color="white">
<link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">id:</th>
            <th scope="col">Movie Title:</th>
            <th scope="col">Genre:</th>
            <th scope="col">Min:</th>
            <th scope="col">Description</th>
            <th scope="col">Author</th>
            <th scope="col">Release Date</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        
        <td scope="row"><?php echo e($movie->id); ?></td>
        <td scope="row"><?php echo e($movie->title); ?></td>
        <td scope="row"><?php echo e($movie->genre); ?></td>
        <td scope="row"><?php echo e($movie->length); ?></td>
        <td scope="row"><?php echo e($movie->description); ?></td>
        <td scope="row"><?php echo e($movie->author); ?></td>
        <td scope="row"><?php echo e($movie->releaseDate); ?></td>
        <td scope="row">
            <a class="btn btn-primary" id="Viewbtn" href="<?php echo e(route('CMSSee',$movie->id)); ?>">View</a>
            <a class="btn btn-primary" id="Editbtn" href="<?php echo e(route('CMSEdit',$movie->id)); ?>">Edit</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table> 
    <section id="pages"><?php echo $movies->render(); ?></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-mainPageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
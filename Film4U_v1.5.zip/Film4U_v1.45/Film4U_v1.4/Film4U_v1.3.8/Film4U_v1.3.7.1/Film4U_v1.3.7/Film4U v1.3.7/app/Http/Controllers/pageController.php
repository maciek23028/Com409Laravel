<?php

namespace App\Http\Controllers;
use View;
use Illuminate\Http\Request;
use App\Movie;

class pageController extends Controller
{
    //
	public function index(){
        $movies=Movie::all();
    	return View::make ('webPages.All')->withMovies($movies);
    }

    public function Mood(){
        $movies=Movie::all();
    	return View::make ('webPages.Mood')->withMovies($movies);
    }
    public function Series(){
         $movies=Movie::all();
    	return View::make ('webPages.Series')->withMovies($movies);
    }
    public function mainPage(){
        return view ('layouts.mainPageLayout');
    }
    public function Profile(){
        return view ('webPages.Profile');
    }
}

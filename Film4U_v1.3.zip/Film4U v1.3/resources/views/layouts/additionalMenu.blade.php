@yield('additionalMenu')
<div class="extraFeatures">
 			<!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">
            </ul>

			<!-- search bar-->
			<!--right side-->
			 <ul class="navbar-nav ml-auto">
                        <div class="searchbar">
                           <div class="search">
                              <input type="text" class="searchTerm" placeholder="Search">
                              <button type="submit" class="searchButton">
                                <i class="fa fa-search" aria-hidden="true"></i>
                             </button>
                           </div>
                        </div>
            </ul>
</div>
@extends('layouts.mainPageLayout')

@section('content')
<link href="{{ asset('css/displayAll.css') }}" rel="stylesheet">
<dir class="rectangle">
		<div>
			<h1>All Movies</h1>
		<ul>
			@foreach ($movies as $movie)
			<p><a href="{{route('showMovie',$movie->id)}}">{{$movie->title}}</a></p>
			<p>Description: {{$movie->description}}</p>
			@endforeach
			
		</ul>
		<br />
		<br />
		<br />
		</div>
</dir>
@stop

<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'full_name' => [
                'required',
                'string',
                'max:60',
                'regex:/[a-z]/',
                'regex:/[A-Z]/'],

             'username' => [
                'required',
                'string',
                'max:20',
                'unique:users',
                'regex:/[a-z]/',
                'regex:/[A-Z]/',
                'regex:/[0-9]/'],

            'email' => ['required', 'string', 'email', 'max:60', 'unique:users'],

            'password' => [
                'required',
                'string',
                'min:8', // must be at least 8 characters long
                'regex:/[a-z]/', //must contain at least 1 letter a-z
                'regex:/[A-Z]/',//must contain at least 1 Capital letter a-z
                'regex:/[0-9]/', //must contain at least 1 number
                'regex:/[@$!%&#]/', //must contain at least 1 special character
                'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        return User::create([
            'full_name' => $data['full_name'],
            'username' => $data['username'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
        ]);
    }
}

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                

                <div class="card-header"><strong>Add Movie</strong></div>

                <section id="pageElements">
                    <form method="post" action="<?php echo e(route('CMSSee')); ?>">
                        <h6>Movie title:</h6>
                        <input type="text" id="oneLiner" required></input>
                        <h6>Genre:</h6>
                        <input type="text" id="oneLiner" required></input>
                        <h6>Length:</h6>
                        <input type="text" id="oneLiner" required></input>
                        <h6>Description:</h6>
                        <textarea></textarea>
                        <h6>Author:</h6>
                        <input type="text" id="oneLiner" required></input>
                        <h6>Release date:</h6>
                        <input type="text" id="oneLiner" required></input>
                        <button type="Submit">Add Movie</button>
                    </form>
                </section>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-mainPageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
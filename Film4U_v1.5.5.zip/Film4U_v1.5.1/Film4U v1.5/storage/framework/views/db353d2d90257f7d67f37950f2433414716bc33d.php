
<?php $__env->startSection('content'); ?>
<!--enter content-->
<link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">

	<section id="pageElements">
			<section id="Images">

				<?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
				
					<a href="<?php echo e(route('showMovie',$movie->id)); ?>">
						<div class="image">
					 <img src="https://ulster-my.sharepoint.com/:i:/r/personal/rozmiarek-m_ulster_ac_uk/Documents/seriesPlaceHolder.jpg?csf=1&e=edIO9R" alt="<?php echo e($movie->title); ?>">
					 </div>
					</a>
				

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</section>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainPageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                        
                <div class="card-header"><?php echo e($movie->title); ?>

                    <div class="form-group row mb-0">

                        <div class="buttonD">
                            <div class="col-md-3 offset-md-10">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Delete')); ?>

                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('CMS')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Movie title')); ?></label>

                            <div class="col-md-6">
                                <input id="title" type="text" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="title" value="<?php echo e(old('title')); ?>" placeholder="<?php echo e($movie->title); ?> " required autofocus>

                                <?php if($errors->has('title')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="genre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Genre')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('genre') ? ' is-invalid' : ''); ?>" name="genre" value="<?php echo e(old('genre')); ?>" placeholder="<?php echo e($movie->genre); ?>" required autofocus>

                                <?php if($errors->has('genre')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('genre')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        

                        <div class="form-group row">
                            <label for="length" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Movie Length')); ?></label>

                            <div class="col-md-6">
                                <input id="length" type="number" class="form-control<?php echo e($errors->has('length') ? ' is-invalid' : ''); ?>" name="length" value="<?php echo e(old('length')); ?>" placeholder="<?php echo e($movie->length); ?>"required>

                                <?php if($errors->has('length')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('length')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-6">
                                <input id="description" type="text" class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" placeholder="<?php echo e($movie->description); ?>" required>

                                <?php if($errors->has('description')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="author" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Author')); ?></label>

                            <div class="col-md-6">
                                <input id="author" type="text" class="form-control<?php echo e($errors->has('author') ? ' is-invalid' : ''); ?>" name="author" placeholder="<?php echo e($movie->author); ?>" required>

                                <?php if($errors->has('author')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('author')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="releaseDate" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Release Date')); ?></label>

                            <div class="col-md-6">
                                <input id="releaseDate" type="string" class="form-control<?php echo e($errors->has('releaseDate') ? ' is-invalid' : ''); ?>" name="releaseDate" placeholder="<?php echo e($movie->releaseDate); ?>" required>

                                <?php if($errors->has('releaseDate')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('releaseDate')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="mediaType_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('1 Movie, 2 Series')); ?></label>

                            <div class="col-md-6">
                                <input id="mediaType_id" type="number" class="form-control<?php echo e($errors->has('mediaType_id') ? ' is-invalid' : ''); ?>" name="mediaType_id" placeholder="<?php echo e($movie->mediaType_id); ?>"required>

                                <?php if($errors->has('movieType_id')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('mediaType_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                    </form>
                    <form method="get" action="<?php echo e(route('CMS')); ?>">
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Back')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
   
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-mainPageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
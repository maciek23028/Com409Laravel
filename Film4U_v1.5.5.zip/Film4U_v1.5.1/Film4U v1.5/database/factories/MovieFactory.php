<?php

use Faker\Generator as Faker;

$factory->define(App\Movie::class, function (Faker $faker) {
    $number = 1;
    return [
        'title' => $faker->name(),
        'genre' => $faker->randomElement(['Action','Comedy','Horror','Adventure','Drama','Documentary','Fantasy']),
        'mediaType_id' => App\Category_Movie::pluck('id')->random(),
        'length' => $faker->numberBetween(15,200),
        'description' => $faker->text(),
        'author' => $faker->name(),
        'releaseDate' => now(),
    ];
});

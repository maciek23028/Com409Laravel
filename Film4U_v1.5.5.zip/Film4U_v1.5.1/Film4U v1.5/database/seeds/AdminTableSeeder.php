<?php
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class AdminTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         //factory(App\Admin::class, 4)->create();
          DB::table('admins')->insert([
            'full_name' => 'Maciej Rozmiarek',
            'username' => 'maciek23028',
            'email' => 'maciek23028@example.com',
            'password' => bcrypt('Kropk@12'),
            'email_verified_at' => now(),
            'remember_token' => str_random(10),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
          DB::table('admins')->insert([
            'full_name' => 'Kristan Tranter',
            'username' => 'kristianT',
            'email' => 'kristianT@example.com',
            'password' => bcrypt('Pas$word'),
            'email_verified_at' => now(),
            'remember_token' => str_random(10),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
          DB::table('admins')->insert([
            'full_name' => 'Connor Doorman',
            'username' => 'connorD',
            'email' => 'connorD@example.com',
            'password' => bcrypt('Pas$word'),
            'email_verified_at' => now(),
            'remember_token' => str_random(10),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
          DB::table('admins')->insert([
            'full_name' => 'Thomas McKeown',
            'username' => 'McKthomas',
            'email' => 'McKthomas@example.com',
            'password' => bcrypt('Pas$word'),
            'email_verified_at' => now(),
            'remember_token' => str_random(10),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
          DB::table('admins')->insert([
            'full_name' => 'admin user',
            'username' => 'admin',
            'email' => 'admin@example.com',
            'password' => bcrypt('Pas$word'),
            'email_verified_at' => now(),
            'remember_token' => str_random(10),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}

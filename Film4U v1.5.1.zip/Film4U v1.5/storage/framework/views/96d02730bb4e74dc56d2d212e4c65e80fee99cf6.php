<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">
<font color="black">
    <div class="pageContent">
        <div class="card">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="moveToRight">
                
                <a class="btn btn-primary" href="#
                "> Update</a>
                <a class="btn btn-primary" href="#
                "> Delete</a>
                <a class="btn btn-primary" href="<?php echo e(route('CMS')); ?>

                "> Back</a>
            </div>
        </div>
        </div>
    </div>
    <div class="pageSquare">
        <div class="pageContent">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Movie Title:</strong>
                <?php echo e($movie->title); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Genre:</strong>
                <?php echo e($movie->genre); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Length:</strong>
                <?php echo e($movie->length); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Description:</strong>
                <?php echo e($movie->description); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Author:</strong>
                <?php echo e($movie->author); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Release Date:</strong>
                <?php echo e($movie->releaseDate); ?>

            </div>
        </div>
        </div>
        </div>

 
 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-mainPageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
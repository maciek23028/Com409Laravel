@extends('layouts.mainPageLayout')

@section('content')
<link href="{{ asset('css/main.css') }}" rel="stylesheet">
<section id="currentLocation">
		<h1>Movies</h1>
</section>
<section id="pageElements">
	<section id="Images">
				@foreach ($movies as $movie )
						<a href="{{route('showMovie',$movie->id)}}">
							<div class="image">
						 <img src="https://ulster-my.sharepoint.com/:i:/r/personal/rozmiarek-m_ulster_ac_uk/Documents/MoviePlaceHolder.jpg?csf=1&e=xDsneS" alt="{{$movie->title}}">
						 </div>
						</a>
				@endforeach
				</section>
			</section>
@stop



@extends('layouts.admin-mainPageLayout')

@section('content')
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-header"><strong>Edit Mode</strong></div>

                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

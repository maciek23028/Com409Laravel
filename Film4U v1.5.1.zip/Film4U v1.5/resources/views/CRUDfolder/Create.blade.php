

@extends('layouts.admin-mainPageLayout')

@section('content')
<link href="{{ asset('css/admin.css') }}" rel="stylesheet">
<font color="black"> 
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <br />
            <br />
            <br />
            <div class="card">
                <br />
                <a class="btn btn-primary" href="{{ route('CMS') }}"> Back</a>


                 @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

         <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <div class="form-item">
                    <br />
                <h6><strong>Movie Title:</strong></h6>
                <input type="text" name="Title">
            </div>
        </div>
        </div>
 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <div class="form-item">

                <h6><strong>Genre:</strong></h6>
                <input type="text" name="Genre">
            </div>
        </div>
        </div>
 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <div class="form-item">

                <h6><strong>Length:</strong></h6>
                <input type="text" name="Length">
            </div>
        </div>
        </div>
 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <div class="form-item">

                <h6><strong>Description:</strong></h6>
                <input type="text" name="Description">
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <div class="form-item">

                <h6><strong>Author:</strong></h6>
                <input type="text" name="Author">
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <div class="form-item">

                <h6><strong>Release Date:</strong></h6>
                <input type="text" name="releaseDate">
            </div>
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center" id="movetoBottom">
                <button type="submit" class="btn btn-primary">Add Movie</button>
        </div>





            </div>
        </div>
    </div>
   
   
@endsection

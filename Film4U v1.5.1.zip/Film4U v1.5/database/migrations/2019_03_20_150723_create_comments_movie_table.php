<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCommentsMovieTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comments_movies', function (Blueprint $table) {
            $table->increments('id')->unique();
            $table->longText('comment');
            $table->unsignedInteger('movie_id');
            $table->unsignedInteger('users_id');
            $table->timestamps();
        });
        schema::table('comments_movies', function($table){
            $table->foreign('movie_id')->references('id')->on('movies');
            $table->foreign('users_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('comments_movies');
    }
}

<?php

use Faker\Generator as Faker;

$factory->define(App\comments_movie::class, function (Faker $faker) {
    return [
        'comment' => $faker->text(),
        'movie_id' => App\Movie::pluck('id')->random(),
        'users_id' => App\Movie::pluck('id')->random()

    ];
});

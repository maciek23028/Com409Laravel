<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category_Movie extends Model
{
            /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'mediaType',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id','movie_id',
    ];
}

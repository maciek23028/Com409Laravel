
<?php $__env->startSection('content'); ?>
<!--enter content-->
<link href="<?php echo e(asset('css/displayAll.css')); ?>" rel="stylesheet">
<div class="rectangle">
	<h1>All</h1>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainPageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
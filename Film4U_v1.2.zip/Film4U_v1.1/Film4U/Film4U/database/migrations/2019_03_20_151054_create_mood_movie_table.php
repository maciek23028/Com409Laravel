<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMoodMovieTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mood_movies', function (Blueprint $table) {
            $table->increments('id')->unique();
            $table->string('mood');
            $table->string('mood2');
            $table->unsignedInteger('movie_id');
        });
        schema::table('mood_movies', function($table){
            $table->foreign('movie_id')->references('id')->on('movies');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mood_movies');
    }
}

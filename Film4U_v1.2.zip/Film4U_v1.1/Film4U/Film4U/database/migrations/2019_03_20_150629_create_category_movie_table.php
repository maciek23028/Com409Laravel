<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCategoryMovieTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('category__movies', function (Blueprint $table) {
            $table->increments('id')->unique();
            $table->unsignedInteger('movie_id')->unique()->nullable();
            $table->string('mediaType');
            $table->timestamps();
            
        });
        schema::table('category__movies', function($table){
            $table->foreign('movie_id')->references('id')->on('movies');
        });
                schema::table('movies', function($table){
            $table->foreign('mediaType_id')->references('id')->on('category__movies');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('category__movies');
    }
}

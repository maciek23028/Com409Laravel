<?php

use Faker\Generator as Faker;

$factory->define(App\Movie::class, function (Faker $faker) {
    $number = 1;
    return [
        'title' => $faker->unique()->randomElement([
        	'MovieTitle'.$number,
        	'MovieTitle'.$number++,
        	'MovieTitle'.$number++,
        	'MovieTitle'.$number++,
        	'MovieTitle'.$number++,
        	'MovieTitle'.$number++,
        	'MovieTitle'.$number++,
        	'MovieTitle'.$number++,
        	'MovieTitle'.$number++,
        ]),
        'genre' => $faker->randomElement(['Action','Comedy','Horror','Adventure','Drama','Documentary','Fantasy']),
        'rating' => $faker->randomFloat(2,0,10),
        'length' => $faker->numberBetween(15,200),
        'description' => $faker->text(),
        'author' => $faker->name(),
        'releaseDate' => now(),

    ];
});

<?php

use Faker\Generator as Faker;

$factory->define(App\Category_Movie::class, function (Faker $faker) {
    return [
        'mediaType' => $faker->randomElement(['Movie','Series',]),
        //'movie_id' => $faker->movies::all()->pluck('id'),
    ];
});

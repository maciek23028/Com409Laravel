<?php

namespace App\Http\Controllers;
use View;
use Illuminate\Http\Request;

class pageController extends Controller
{
    //
	public function index(){
    	return View::make ('webPages.All');
    }

    public function Mood(){
    	return View::make ('webPages.Mood');
    }
    public function Series(){
    	return View::make ('webPages.Series');
    }
    public function mainPage(){
        return view ('layouts.mainPageLayout');
    }
}

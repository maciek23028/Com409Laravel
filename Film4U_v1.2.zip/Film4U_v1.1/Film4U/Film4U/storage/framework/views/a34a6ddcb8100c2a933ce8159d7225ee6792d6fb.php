

<?php $__env->startSection('content'); ?>
<div>
	<h1>Content of card <?php echo e($card); ?></h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->startSection('content'); ?>
<div>
	<h1>All Movies</h1>
<ul>
	<?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<p><a href="<?php echo e(route('showMovie',$movie->id)); ?>"><?php echo e($movie->title); ?></a></p> <p>Description: <?php echo e($movie->description); ?></p>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
</ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainPageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
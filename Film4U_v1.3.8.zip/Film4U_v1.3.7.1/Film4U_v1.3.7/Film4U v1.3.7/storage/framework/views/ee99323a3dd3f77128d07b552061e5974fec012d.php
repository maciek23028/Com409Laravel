
<?php echo $__env->make('layouts.admin-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('admin-header'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.additionalMenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('additionalMenu'); ?>
<?php $__env->stopSection(); ?>

<br />
<br />
<br />
<br />
<div class='pageContent'>
        <main class="py-4">
             <?php echo $__env->yieldContent('content'); ?>
             <!----page content ----->
             <!----end of page content ----->
        </main>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

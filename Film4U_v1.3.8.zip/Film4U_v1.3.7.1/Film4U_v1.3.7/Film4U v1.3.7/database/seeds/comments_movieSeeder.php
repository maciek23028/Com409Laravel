<?php

use Illuminate\Database\Seeder;

class comments_movieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\comments_movie::class, 20)->create();
    }
}

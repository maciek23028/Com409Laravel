<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRatingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ratings', function (Blueprint $table) {
            $table->increments('id')->unique();
            $table->unsignedInteger('movie_id');
            $table->unsignedInteger('users_id');
            $table->decimal('rating',3,1);
            $table->timestamps();
        });
        schema::table('ratings', function($table){
            $table->foreign('movie_id')->references('id')->on('movies');
            $table->foreign('users_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ratings');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cast extends Model
{
	public $timestamps = false;
                /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'actor_id','characterPlayed','movie_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id', 'movie_id','actor_id',
    ];
}

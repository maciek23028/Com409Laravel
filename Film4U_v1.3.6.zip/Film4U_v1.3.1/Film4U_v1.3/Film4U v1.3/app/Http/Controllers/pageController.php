<?php

namespace App\Http\Controllers;
use View;
use Illuminate\Http\Request;

use DB;
use App\Movie;
use App\PhotoLocation;

class pageController extends Controller
{
    //
	public function index(){
        $movies=Movie::all();
    	return View::make ('webPages.All')->withMovies($movies);
    }

    public function Mood(){
    	return View::make ('webPages.Mood');
    }
    public function Series(){
    	return View::make ('webPages.Series');
    }
    public function mainPage(){
        return view ('layouts.mainPageLayout');
    }
}

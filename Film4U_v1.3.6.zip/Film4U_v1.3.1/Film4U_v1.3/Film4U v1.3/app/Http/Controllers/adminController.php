<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class adminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('adminDashboard');
    }
    public function adminLogin()
    {
        return view('adminLogin');
    }
    public function adminVerify()
    {
        return view('adminVerify');
    }
    public function adminEmail()
    {
        return view('adminEmail');
    }
    public function adminReset()
    {
        return view('adminReset');
    }

}

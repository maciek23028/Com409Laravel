<?php
/*'photoPath' => $faker->randomElement([
        	'\resources\images\{{$movie->title}}'.$number,*/
use Faker\Generator as Faker;
$factory->define(App\PhotoLocation::class, function (Faker $faker) {
	$number = 1;
    return [
        'photoPath' => $faker->randomElement([
        	'\resources\images\MovieImagePlaceholder'.$number.".jpg",
        	'\resources\images\ '.'{{$movie->title}}'.".jpg",
        ]),
        'movie_id' => App\Movie::pluck('id')->random(),
    ];
});

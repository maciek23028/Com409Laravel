<?php

use Faker\Generator as Faker;

$factory->define(App\mood_movie::class, function (Faker $faker) {
    return [
        'movie_id' => App\Movie::pluck('id')->random(),
        'mood' => $faker->randomElement(['Funny','scary','sad','happy','depressing','cool','empowering']),
        'mood2' => $faker->randomElement(['Funny','scary','sad','happy','depressing','cool','empowering']),
    ];
});

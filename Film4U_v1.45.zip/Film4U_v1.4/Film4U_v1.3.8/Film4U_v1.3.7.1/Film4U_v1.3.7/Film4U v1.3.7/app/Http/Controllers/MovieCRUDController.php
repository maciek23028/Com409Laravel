<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Movie;
use App\Http\Controllers\Controller;
class MovieCRUDController extends Controller
{
        public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function guard(){
        return Auth::guard('admin');
    }



	public function CMS(Request $request)
    {   $movies = Movie::orderBy('id','DESC')->paginate(10);
        return view('CMS' , compact('movies'))->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function CMSCreate(){
        return view('CRUDfolder.Create');
    }

    public function save(Request $request)
    {
      $this->validate($request, [
            'title' => 'required',
            'genre' => 'required',
            'length' => 'required|numeric',
            'description' => 'required',
            'author' => 'required',
        ]); 
        $requestData = $request->all();
        Movie::create($requestData);
        return redirect()->route('CMS')
                        ->with('success','Record created successfully');
    }

    public function CMSSee(Movie $movie)
    {
        $movie = Movie::find($movie);
        return view('CRUDfolder.See',compact('movie'))->withMovie($movie);
    }
 
    public function CMSEdit($id)
    {
        $movie = Movie::find($id);
        return view('CRUDfolder.Edit',compact('movie'));
    }
 
    public function CMSUpdate(Request $request, $id)
    {
         $this->validate($request, [
            'title' => 'required',
            'genre' => 'required',
            'length' => 'required|numeric',
            'description' => 'required',
            'author' => 'required',
            'releaseDate' => now(),
        ]);
        $requestData = $request->all();
        Movie::find($id)->update($requestData);
        return redirect()->route('CRUDfolder.CMS')
                        ->with('success','Record updated successfully');
    }
    public function CMSDelete($id)
    {
        Movie::find($id)->delete();
        return redirect()->route('CRUDfolder.CMS')
                        ->with('success','Record deleted successfully');
    }
}



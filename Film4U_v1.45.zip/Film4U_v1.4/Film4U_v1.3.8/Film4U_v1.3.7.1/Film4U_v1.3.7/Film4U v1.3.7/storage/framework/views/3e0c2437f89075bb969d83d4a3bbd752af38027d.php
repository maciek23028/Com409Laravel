<?php $__env->startSection('content'); ?>

<font color="white"> 
<link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <table class="table table-bordered" white-space="nowrap" >
        <tr>
            <th>id:</th>
            <th>Movie Title:</th>
            <th>Genre:</th>
            <th>Min:</th>
            <th>Description</th>
            <th>Author</th>
            <th>Release Date</th>
            <th>Action</th>
        </tr>
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($movie->title); ?></td>
        <td><?php echo e($movie->genre); ?></td>
        <td><?php echo e($movie->length); ?></td>
        <td><?php echo e($movie->description); ?></td>
        <td><?php echo e($movie->author); ?></td>
        <td><?php echo e($movie->releaseDate); ?></td>
        <td>
            <a class="btn btn-info" id="Viewbtn" href="<?php echo e(route('CMSSee',$movie->id)); ?>">View</a>
            <a class="btn btn-primary" id="Editbtn" href="<?php echo e(route('CMSEdit',$movie->id)); ?>">Edit</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table> 
    <section id="pages"><?php echo $movies->render(); ?></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-mainPageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
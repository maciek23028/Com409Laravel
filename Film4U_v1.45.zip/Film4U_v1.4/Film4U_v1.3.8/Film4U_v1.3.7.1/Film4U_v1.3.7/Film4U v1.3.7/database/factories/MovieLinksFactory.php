<?php

use Faker\Generator as Faker;

$factory->define(App\MovieLink::class, function (Faker $faker) {
    return [
        'link_to_platform' => $faker->randomElement([
        	'https://www.netflix.com/gb/',
        	'https://www.primevideo.com/',
        	'https://www.putlockers.me/',
        	'https://www.hulu.com/',
        	'https://www.sling.com/',
        	'https://www.directvnow.com/',
        	'https://www.fubo.tv/',
        	'https://www.playstation.com/en-us/network/vue/',
        	'https://www.sky.com/watch',
        	'https://tv.youtube.com/welcome/',
        	'https://www.sho.com/',
        ]),
        'movie_id' => App\Movie::pluck('id')->random(),
    ];
});

<?php

use Faker\Generator as Faker;

$factory->define(App\Admin::class, function (Faker $faker) {
    return [
            'full_name' => $faker->unique()->randomElement(['Kristian Tranter','Maciej Rozmiarek','Connor Doorman','Thomas McKeown','AdminUser']),
            'username' => $faker->unique()->randomElement(['maciek2302','kristian','connorD','admin','thomasKmc']),
            'email' => $faker->unique()->randomElement(['kt@example.org','mr@example.org','cd@example.org','tmck@example.org','admin@example.org']),
            'email_verified_at' => now(),
            'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', // secret
        	'remember_token' => str_random(10),
    ];
});

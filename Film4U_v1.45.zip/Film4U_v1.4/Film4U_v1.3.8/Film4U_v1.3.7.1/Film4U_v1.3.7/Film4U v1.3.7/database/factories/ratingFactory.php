<?php

use Faker\Generator as Faker;

$factory->define(App\rating::class, function (Faker $faker) {
    return [
        'rating' => $faker->randomFloat(2,0,10),
        'movie_id' => App\Movie::pluck('id')->random(),
        'users_id' => App\User::pluck('id')->random(),
    ];
});

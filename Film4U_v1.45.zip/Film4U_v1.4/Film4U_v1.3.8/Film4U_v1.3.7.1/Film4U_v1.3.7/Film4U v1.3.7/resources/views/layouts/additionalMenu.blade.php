@yield('additionalMenu')
	<div class="extraFeatures">
				<!-- icons-->
	<i class="fa fa-search" aria-hidden="true"></i> 
				<!-- search bar-->

	        <div class="searchbar">
	            <div class="search">
	                <input type="text" class="searchTerm" placeholder="Search">              
	                <button type="submit" class="searchButton">
	                <i class="fa fa-search" aria-hidden="true"></i>                
	                </button>                           
	             </div>                             
	          </div>                              
	</div>
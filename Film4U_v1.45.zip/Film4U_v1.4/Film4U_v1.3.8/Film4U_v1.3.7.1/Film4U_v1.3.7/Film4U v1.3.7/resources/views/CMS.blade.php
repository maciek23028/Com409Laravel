

@extends ('layouts.admin-mainPageLayout')

@section('content')

<font color="white"> 
<link href="{{ asset('css/admin.css') }}" rel="stylesheet">

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
    <table class="table table-bordered" white-space="nowrap" >
        <tr>
            <th>id:</th>
            <th>Movie Title:</th>
            <th>Genre:</th>
            <th>Min:</th>
            <th>Description</th>
            <th>Author</th>
            <th>Release Date</th>
            <th>Action</th>
        </tr>
    @foreach ($movies as $movie)

    <tr>
        <td>{{ ++$i }}</td>
        <td>{{ $movie->title }}</td>
        <td>{{ $movie->genre }}</td>
        <td>{{ $movie->length }}</td>
        <td>{{ $movie->description }}</td>
        <td>{{ $movie->author}}</td>
        <td>{{ $movie->releaseDate }}</td>
        <td>
            <a class="btn btn-info" id="Viewbtn" href="{{route('CMSSee',$movie->id)}}">View</a>
            <a class="btn btn-primary" id="Editbtn" href="{{ route('CMSEdit',$movie->id) }}">Edit</a>
        </td>
    </tr>
    @endforeach
    </table> 
    <section id="pages">{!! $movies->render() !!}</section>
@endsection
